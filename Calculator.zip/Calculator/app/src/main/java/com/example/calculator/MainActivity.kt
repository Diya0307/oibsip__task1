package com.example.calculator

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.mozilla.javascript.Context
import org.mozilla.javascript.Scriptable

class MainActivity : AppCompatActivity() {
   lateinit var btnC: Button
    lateinit var btnDel: Button
    lateinit var btnMod: Button
    lateinit var btnDiv: Button
    lateinit var btnSeven: Button
    lateinit var btnEight: Button
    lateinit var btnNine: Button
    lateinit var btnMul: Button
    lateinit var btnFive: Button
    lateinit var btnFour: Button
    lateinit var btnSix: Button
    lateinit var btnAdd: Button
    lateinit var btnMinus: Button
    lateinit var btnOne: Button
    lateinit var btnTwo: Button
    lateinit  var btnThree: Button
    lateinit var btnEqual: Button
    lateinit var btnDot: Button
    lateinit var btnZero: Button
    lateinit var txtInput: TextView
     lateinit var txtOutput: TextView
    lateinit var process: String
    lateinit var result: String
    @SuppressLint("SetTextI18n")
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnC = findViewById(R.id.btnC)
        btnDel = findViewById(R.id.btnDel)
        btnMod = findViewById(R.id.btnMod)
        btnDiv = findViewById(R.id.btnDiv)
        btnSeven = findViewById(R.id.btnSeven)
        btnEight = findViewById(R.id.btnEight)
        btnNine = findViewById(R.id.btnNine)
        btnMul = findViewById(R.id.btnMultiply)
        btnFive = findViewById(R.id.btnFive)
        btnFour = findViewById(R.id.btnFour)
        btnSix = findViewById(R.id.btnSix)
        btnAdd = findViewById(R.id.btnAdd)
        btnMinus = findViewById(R.id.btnMinus)
        btnOne = findViewById(R.id.btnOne)
        btnTwo = findViewById(R.id.btnTwo)
        btnThree = findViewById(R.id.btnThree)
        btnEqual = findViewById(R.id.btnEquals)
        btnDot = findViewById(R.id.btnDot)
        btnZero = findViewById(R.id.btnZero)
        txtInput = findViewById(R.id.txtInput)
        txtOutput = findViewById(R.id.txtOutput)
        process=""
        btnC.setOnClickListener {
            txtInput.text = ""
            txtOutput.text = ""
        }
        btnNine.setOnClickListener {
            txtInput.text = "${txtInput.text}9"
        }
        btnEight.setOnClickListener {
            txtInput.text = "${txtInput.text}8"
        }
        btnSeven.setOnClickListener {
            txtInput.text = "${txtInput.text}7"
        }
        btnSix.setOnClickListener {
            txtInput.text = "${txtInput.text}6"
        }
        btnFive.setOnClickListener {
            txtInput.text = "${txtInput.text}5"
        }
        btnFour.setOnClickListener {
            txtInput.text = "${txtInput.text}4"
        }
        btnThree.setOnClickListener {
            txtInput.text = "${txtInput.text}3"
        }
        btnTwo.setOnClickListener {
            txtInput.text = "${txtInput.text}2"
        }
        with(btnOne) {
            setOnClickListener({
                txtInput.text="${txtInput.text}1"
            })
        }
        btnZero.setOnClickListener {
            txtInput.text = "${txtInput.text}0"
        }
        btnMinus.setOnClickListener {
            txtInput.text = "${txtInput.text}-"
        }
        btnAdd.setOnClickListener {
            txtInput.text = "${txtInput.text}+"
        }
        btnMul.setOnClickListener {
            process = btnMul.getText().toString()
            txtInput.text = "${txtInput.text}*"
        }
        btnDiv.setOnClickListener {
            txtInput.text = "${txtInput.text}/"
        }
        btnMod.setOnClickListener {
            txtInput.text = "${txtInput.text}%"
        }
        btnDel.setOnClickListener {
            val text = txtInput.text.toString()
            if (text.isNotEmpty()) {
                txtInput.text = text.dropLast(1)
            }
            txtInput.text = "${txtInput.text}"
            txtOutput.text = ""
        }

        btnDot.setOnClickListener {
            txtInput.text = "${txtInput.text}."
        }
        btnEqual.setOnClickListener {
            process = txtInput.getText().toString()
            val rhino = Context.enter()
            rhino.optimizationLevel = -1
            result = ""
            result = try {
                val scope: Scriptable = rhino.initStandardObjects()
                rhino.evaluateString(scope, txtInput.text.toString(), "javascript", 1, null)
                    .toString()
            } catch (e: Exception) {
                "0"
            }
            txtOutput.text = "= ${result}"
        }
    }

}